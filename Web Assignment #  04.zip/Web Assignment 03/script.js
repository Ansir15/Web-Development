const quizContainer = document.getElementById("quiz");
const submitBtn = document.getElementById("submitBtn");
const resultContainer = document.getElementById("result");

fetch("questions.json")
  .then((response) => {
    if (!response.ok) throw new Error("Failed to load questions.");
    return response.json();//respose ko json format me convert krega
  })
  .then((questions) => {
    displayQuiz(questions);

    submitBtn.addEventListener("click", () => {
      evaluateQuiz(questions);
    });
  })
  .catch((error) => {
    quizContainer.innerHTML = `<p style="color:red;">Error loading quiz: ${error.message}</p>`;
  });
function displayQuiz(questions) {
  quizContainer.innerHTML = "";

  questions.forEach((q, index) => {
    const questionDiv = document.createElement("div");
    questionDiv.classList.add("question");

    const qText = document.createElement("p");
    qText.textContent = `${index + 1}. ${q.question}`;
    questionDiv.appendChild(qText);

    q.options.forEach((opt, i) => {
      const radioId = `q${index}_opt${i}`;

      const radioInput = document.createElement("input");
      radioInput.type = "radio";
      radioInput.id = radioId;
      radioInput.name = `q${index}`;
      radioInput.value = i;

      const label = document.createElement("label");
      label.setAttribute("for", radioId);
      label.textContent = opt;

      questionDiv.appendChild(radioInput);
      questionDiv.appendChild(label);
      questionDiv.appendChild(document.createElement("br"));
    });

    quizContainer.appendChild(questionDiv);
  });
}
function evaluateQuiz(questions) {
  let score = 0;

  questions.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q${index}"]:checked`);
    const questionDiv = quizContainer.children[index];

    const radios = questionDiv.querySelectorAll("input[type=radio]");
    radios.forEach((radio, i) => {
      const label = radio.nextSibling;
      if (i === q.correctIndex) {
        label.style.color = "green";
      }
      if (selected && parseInt(selected.value) === i && i !== q.correctIndex) {
        label.style.color = "red";
      }
    });
    if (selected && parseInt(selected.value) === q.correctIndex) {
      score++;
    }
  });
  resultContainer.innerHTML = `<h3>Your Score: ${score} / ${questions.length}</h3>`;
}
