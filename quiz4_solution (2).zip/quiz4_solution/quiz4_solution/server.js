require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');

const authRoutes = require('./src/routes/auth');
const productRoutes = require('./src/routes/products');
const app = express();
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: ' API running' });
});

app.use('/users', authRoutes);
app.use('/products', productRoutes);

const PORT = process.env.PORT || 9000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/product';

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  });
