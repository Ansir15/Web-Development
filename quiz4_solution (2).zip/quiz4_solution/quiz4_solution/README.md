# Quiz 4 Solution (Web Application Development)

This folder contains the required code parts:

- **Login API** with JWT token generation: `POST /users/login`
- **Token verification middleware**: `src/middleware/verifyToken.js`
- **Secured edit API**: `PUT /products/:id` protected with token verification

## Setup

1. Install dependencies

```bash
npm install
```

2. Create `.env` file

```bash
cp .env.example .env
```

Set `JWT_SECRET` and `MONGO_URI`.

3. Run server

```bash
npm start
```

## Endpoints

### Register
`POST /users/register`

Body:
```json
{ "username": "ali", "email": "ali@example.com", "password": "123456" }
```

### Login (JWT Token)
`POST /users/login`

Body:
```json
{ "username": "ali", "password": "123456" }
```

Response:
```json
{ "message": "Login successful", "token": "<jwt>" }
```

### Update Product (Secured)
`PUT /products/:id`

Header:
`Authorization: Bearer <jwt>`

Body (example):
```json
{ "price": 999, "quantity": 3 }
```
