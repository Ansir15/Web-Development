const express = require('express');

const Product = require('../models/Product');
const verifyToken = require('../middleware/verifyToken');

const router = express.Router();

/**
 * PUT /products/:id
 * Secured: requires JWT
 * Body can include any product fields to update
 */
router.post("/", verifyToken, async (req, res) => {
  try {
    const { name, price, quantity } = req.body;

    if (!name || price == null || quantity == null) {
      return res.status(400).json({ message: "name, price, quantity required" });
    }

    const product = await Product.create({ name, price, quantity });
    res.status(201).json(product);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
});
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const { id } = req.params;

    const allowed = ['name', 'price', 'quantity', 'description'];
    const update = {};
    for (const key of allowed) {
      if (req.body[key] !== undefined) update[key] = req.body[key];
    }

    if (Object.keys(update).length === 0) {
      return res.status(400).json({ message: 'No valid fields provided to update' });
    }

    const product = await Product.findByIdAndUpdate(id, update, { new: true, runValidators: true });

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    return res.json({ message: 'Product updated successfully', product });
  } catch (err) {
     console.log(err);
    return res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
