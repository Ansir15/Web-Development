document.addEventListener('DOMContentLoaded', function() {
  // Header scroll effect
  const header = document.getElementById('header');
  window.addEventListener('scroll', function() {
      if (window.scrollY > 50) {
          header.classList.add('scrolled');
      } else {
          header.classList.remove('scrolled');
      }
  });

  // Mobile menu toggle
  const menuBtn = document.querySelector('.menu-btn');
  const navLinks = document.querySelector('.nav-links');
  const menuIcon = menuBtn.querySelector('i');

  menuBtn.addEventListener('click', function() {
      navLinks.classList.toggle('active');
      menuIcon.classList.toggle('fa-times');
  });

  // Close mobile menu when clicking a link
  document.querySelectorAll('.nav-links a').forEach(function(link) {
      link.addEventListener('click', function() {
          navLinks.classList.remove('active');
          menuIcon.classList.remove('fa-times');
      });
  });

  // Smooth scrolling
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
          e.preventDefault();
          const targetId = this.getAttribute('href');
          if (targetId === '#') return;
          
          const targetElement = document.querySelector(targetId);
          if (targetElement) {
              const headerHeight = header.offsetHeight;
              window.scrollTo({
                  top: targetElement.offsetTop - headerHeight,
                  behavior: 'smooth'
              });
          }
      });
  });

  // Music player toggle
  const musicBtn = document.getElementById('musicBtn');
  const workoutMusic = document.getElementById('workoutMusic');
  const musicIcon = musicBtn.querySelector('i');
  let isPlaying = false;

  musicBtn.addEventListener('click', function() {
      if (isPlaying) {
          workoutMusic.pause();
          musicIcon.classList.replace('fa-pause', 'fa-music');
      } else {
          workoutMusic.play();
          musicIcon.classList.replace('fa-music', 'fa-pause');
      }
      isPlaying = !isPlaying;
  });

  // Modal functionality
  const newsletterModal = document.getElementById('newsletterModal');
  const joinBtn = document.getElementById('joinBtn');
  const closeModal = document.querySelector('.close-modal');

  function showModal() {
      newsletterModal.classList.add('show');
      document.body.style.overflow = 'hidden';
  }

  function hideModal() {
      newsletterModal.classList.remove('show');
      document.body.style.overflow = '';
  }

  joinBtn.addEventListener('click', function(e) {
      e.preventDefault();
      showModal();
  });

  closeModal.addEventListener('click', hideModal);
  newsletterModal.addEventListener('click', function(e) {
      if (e.target === newsletterModal) hideModal();
  });

  document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && newsletterModal.classList.contains('show')) {
          hideModal();
      }
  });

  // Form validation
  document.querySelectorAll('form').forEach(function(form) {
      form.addEventListener('submit', function(e) {
          e.preventDefault();
          let isValid = true;
          let errorMessage = '';
          
          form.querySelectorAll('[required]').forEach(function(input) {
              if (!input.value.trim()) {
                  isValid = false;
                  errorMessage = 'Please fill in all required fields';
                  input.classList.add('error');
              } else {
                  input.classList.remove('error');
                  
                  if (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) {
                      isValid = false;
                      errorMessage = 'Please enter a valid email address';
                      input.classList.add('error');
                  }
                  
                  if (input.type === 'tel' && input.value.trim() && !/^[0-9]{10,15}$/.test(input.value.replace(/[\s-]/g, ''))) {
                      isValid = false;
                      errorMessage = 'Please enter a valid phone number';
                      input.classList.add('error');
                  }
              }
          });
          
          if (isValid) {
              alert('Form submitted successfully! Thank you!');
              form.reset();
              if (form.closest('.modal-content')) hideModal();
          } else {
              alert(errorMessage || 'Please correct the errors in the form');
          }
      });
  });

  // Scroll animations
  function animateOnScroll() {
      const elements = document.querySelectorAll('[data-aos]');
      elements.forEach(el => {
          const elementTop = el.getBoundingClientRect().top;
          const windowHeight = window.innerHeight;
          
          if (elementTop < windowHeight - 100) {
              el.style.opacity = 1;
              el.style.transform = 'translateY(0)';
          }
      });
  }

  // Initialize elements with animation properties
  document.querySelectorAll('[data-aos]').forEach(el => {
      el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      el.style.opacity = 0;
      el.style.transform = 'translateY(20px)';
  });

  // Show newsletter modal after delay
  if (!localStorage.getItem('modalShown')) {
      setTimeout(showModal, 1000);
      localStorage.setItem('modalShown', 'true');
  }

  // Initial animation check
  animateOnScroll();
  window.addEventListener('scroll', animateOnScroll);
});
